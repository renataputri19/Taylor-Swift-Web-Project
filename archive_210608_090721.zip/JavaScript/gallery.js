function ganti(id) {
    var foto = document.getElementById(id).src;
    document.getElementById("jumbo").src = foto;
}